
#import "CameraViewController.h"
#include "XJGARSDKGPUImage.h"
#include "XJGArSdk.h"
#import "XJGARSDKFilterCollectionViewCell.h"
#import "XJGARSDKStickerCollectionViewCell.h"


#define collectionViewHeight  100
#define filterButton_WithHeight 40

@interface CameraSampleViewController()<UICollectionViewDataSource,UICollectionViewDelegate,XJGARSDKChangeResDelegate>{
    GPUImgLuo::XJGARSDKCameraOperator* camera;
    XJGARSDKGPUImageView* filteredView;
    XJGARSDKFilterType curFilterType;
    XJGARSDKStickerType curStickerType;
    UITextField* textHint;
    unsigned char* processedFrameDataForSave;
    
    UISlider* slider_skinsmooth;
    UISlider* slider_redface;
    UISlider* slider_skinwhiten;
    UISlider* slider_bigeye;
    UISlider* slider_chinsurgery;
    
    UILabel* labelmslider;
    UILabel* labelrslider;
    UILabel* labelrwslider;
    UILabel* labelbslider;
    UILabel* labelsslider;
    
}

@end

@implementation CameraSampleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //设置视图的标题
    self.title = @"Camera Sample";
    
    self.isShowFilterView = NO;
    self.isShowBeautyView = NO;
    
    CGRect mainScreenFrame = [[UIScreen mainScreen] bounds];
    
    //初始化过滤后的视图
    filteredView = [[XJGARSDKGPUImageView alloc] initWithFrame:mainScreenFrame];
    //创建一个纯视图，非过滤后的原始视图？？
    XJGARSDKGPUImageView* pureView = [[XJGARSDKGPUImageView alloc] initWithFrame:CGRectMake(mainScreenFrame.size.width - 110, 80.0, 100, 100)];
    [pureView setFillMode:GPUImagViewFillMode::PreserveAspectRatioAndFill];

    self.view = filteredView;
    [self.view addSubview:pureView];//dds a view to the end of the receiver’s list of subviews.
    
    [self.view addSubview:self.filtercollectionView];
    [self.view addSubview:self.stickercollectionView];
    [self.view bringSubviewToFront:self.filtercollectionView];    //把滤镜的collectionview放在顶层，这样滤镜显示控件能始终盖住相机切换和保存图片的控件
  
   // CGFloat interval = 60;
   
    
    // choose filter btn 滤镜选择按钮
    CGFloat  defaultMargin = self.view.bounds.size.width * 0.1;
    UIButton* chooseFilterBtn = [[UIButton alloc] initWithFrame:CGRectMake(defaultMargin, self.view.bounds.size.height - 40 ,filterButton_WithHeight, filterButton_WithHeight)];
  //  [chooseFilterBtn setBackgroundColor:[UIColor colorWithWhite:0.7 alpha:0.5]];
    [chooseFilterBtn setImage:[UIImage imageNamed:@"ic_camera_filter"] forState:UIControlStateNormal];
    [chooseFilterBtn addTarget:self action:@selector(chooseFilterBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:chooseFilterBtn];
    
    
    // flip camera btn 相机切换的按钮
    UIButton* flipCameraBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.view.bounds.size.width -defaultMargin-filterButton_WithHeight , 60, filterButton_WithHeight, filterButton_WithHeight)];
    [flipCameraBtn setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    //[flipCameraBtn setBackgroundColor:[UIColor colorWithWhite:0.7 alpha:0.5]];
    [flipCameraBtn setImage:[UIImage imageNamed:@"record_camera_switch_press"] forState:UIControlStateNormal];
    [flipCameraBtn addTarget:self action:@selector(flipCameraBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:flipCameraBtn];
   
    
    
    // choose sticker papers 贴纸选择
    //UIButton* stickerSelImageBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.view.bounds.size.width -defaultMargin-filterButton_WithHeight , chooseFilterBtn.frame.origin.y, filterButton_WithHeight, filterButton_WithHeight)];
    // [stickerSelImageBtn setTitle:@"Chooose Sticker" forState:UIControlStateNormal];
    // [stickerSelImageBtn setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
    //[stickerSelImageBtn setBackgroundColor:[UIColor colorWithWhite:0.7 alpha:0.5]];
   // [stickerSelImageBtn setImage:[UIImage imageNamed:@"1_1_c_30x30_"] forState:UIControlStateNormal];
   // [stickerSelImageBtn addTarget:self action:@selector(chooseStickerPaperBtnAction:) forControlEvents:UIControlEventTouchUpInside];
   // [self.view addSubview:stickerSelImageBtn];
    
    
    // choose beauty papers 美颜选择
    UIButton* beautyBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.view.bounds.size.width -defaultMargin-filterButton_WithHeight , chooseFilterBtn.frame.origin.y, filterButton_WithHeight, filterButton_WithHeight)];
    //[beautyBtn setBackgroundColor:[UIColor colorWithWhite:0.7 alpha:0.5]];
    [beautyBtn setImage:[UIImage imageNamed:@"ic_camera_beauty"] forState:UIControlStateNormal];
    [beautyBtn addTarget:self action:@selector(chooseBeautyBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:beautyBtn];

    
    // save image btn 保存图像按钮
     UIButton* saveImageBtn = [[UIButton alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - filterButton_WithHeight)*0.45 , chooseFilterBtn.frame.origin.y-filterButton_WithHeight*0.8, filterButton_WithHeight*2.0, filterButton_WithHeight*2.0)];
    //[saveImageBtn setTitleColor:[UIColor blackColor] forState:UIControlStateHighlighted];
   // [saveImageBtn setBackgroundColor:[UIColor colorWithWhite:0.7 alpha:1.0]];
    [saveImageBtn setImage:[UIImage imageNamed:@"button_take_pic_normal"] forState:UIControlStateNormal];
    [saveImageBtn addTarget:self action:@selector(saveImageBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:saveImageBtn];
    processedFrameDataForSave = 0;
    
   // self.circleView.bounds = CGRectMake(0, 0, 80, 30);
  //  self.circleView.center = CGPointMake(self.view.frame.size.width*0.5, self.view.frame.size.height -40-30);
   // processedFrameDataForSave = 0;
   // [self.view addSubview:self.circleView];
    
    // filter text field 过滤参数的文本显示
   // textHint = [[UITextField alloc]initWithFrame:CGRectMake(10, 80.0, 400, 30)];
   // [textHint setText:@"Filter: Brightness"];
    //textHint.textColor = [UIColor yellowColor];
   // [self.view addSubview:textHint];
    

    XJGARSDKSetOptimizationMode(0);//optimizing for video
    
    //XJGARSDKSetOptimizationMode(2);//optimizing for video using asychronized face detection thread,异步线程实现人脸对齐检测的视频模式
    //XJGARSDKSetOptimizationMode(0);//optimizing for video, default, 视频模式,默认
    //XJGARSDKSetOptimizationMode(1);//optimizing for image, 图片模式
    
    
    camera = GPUImgLuo::XJGARSDKCameraOperator::create();
    camera->setOutputImageOrientation(UIInterfaceOrientationPortrait);
//    camera->setHorizontallyMirrorFrontFacingCamera(true);
    camera->addTargetLarge( filteredView );//将直接显示相机内容的纯视图（不做其他操作）加入到相机的渲染目标中
    camera->addTargetSmall(pureView);//addTarget仍然会返回一个source对象
    camera->start();

}

//显示美颜选择View
- (void)showBeautysliderView
{
    if(self.isShowBeautyView) return;
   
    
    // 磨皮 创建参数调节的滚动条
    UISlider* slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, 285,[UIScreen mainScreen].bounds.size.width - 50.0, 40.0)];
    //UISlider* slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, mainScreenFrame.size.height - interval * 3, mainScreenFrame.size.width - 50.0, 40.0)];
    labelmslider =[[UILabel alloc] initWithFrame:CGRectMake(slider.frame.origin.x, slider.frame.origin.y ,103,21)];
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    slider.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    slider.minimumValue = 0.0;
    slider.maximumValue = 100.0;
    slider.value = 50.0;
    labelmslider.text = @"磨皮";
    labelmslider.textColor =[UIColor yellowColor];
    [self.view addSubview:slider];
    [self.view addSubview:labelmslider];
    slider_skinsmooth = slider;
    
    //红润
    //slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, mainScreenFrame.size.height - interval * 2, mainScreenFrame.size.width - 50.0, 40.0)];
    slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, 245, [UIScreen mainScreen].bounds.size.width - 50.0, 40.0)];
    labelrslider =[[UILabel alloc] initWithFrame:CGRectMake(slider.frame.origin.x, slider.frame.origin.y,103,21)];
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    slider.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    slider.minimumValue = 0.0;
    slider.maximumValue = 100.0;
    slider.value = 50.0;
    labelrslider.text = @"红润";
    labelrslider.textColor =[UIColor yellowColor];
    [self.view addSubview:slider];
    [self.view addSubview:labelrslider];
    slider_redface = slider;
    
    //美白
    slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, 205, [UIScreen mainScreen].bounds.size.width - 50.0, 40.0)];
    //slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, mainScreenFrame.size.height - interval * 1, mainScreenFrame.size.width - 50.0, 40.0)];
    labelrwslider =[[UILabel alloc] initWithFrame:CGRectMake(slider.frame.origin.x, slider.frame.origin.y,103,21)];
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    slider.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    slider.minimumValue = 0.0;
    slider.maximumValue = 100.0;
    slider.value = 50.0;
    labelrwslider.text = @"美白";
    labelrwslider.textColor =[UIColor yellowColor];
    [self.view addSubview:slider];
    [self.view addSubview:labelrwslider];
    slider_skinwhiten = slider;
    
    //大眼
    //slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, mainScreenFrame.size.height - interval * 4, mainScreenFrame.size.width - 50.0, 40.0)];
    slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, 165, [UIScreen mainScreen].bounds.size.width - 50.0, 40.0)];
    labelbslider =[[UILabel alloc] initWithFrame:CGRectMake(slider.frame.origin.x, slider.frame.origin.y,103,21)];
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    slider.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    slider.minimumValue = 0.0;
    slider.maximumValue = 100.0;
    slider.value = 50.0;
    labelbslider.text = @"大眼";
    labelbslider.textColor =[UIColor yellowColor];
    [self.view addSubview:slider];
    [self.view addSubview:labelbslider];
    slider_bigeye = slider;
    
    //瘦脸
    //slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, mainScreenFrame.size.height - interval * 5, mainScreenFrame.size.width - 50.0, 40.0)];
    slider = [[UISlider alloc] initWithFrame:CGRectMake(25.0, 125, [UIScreen mainScreen].bounds.size.width - 50.0, 40.0)];
    labelsslider =[[UILabel alloc] initWithFrame:CGRectMake(slider.frame.origin.x, slider.frame.origin.y,103,21)];
    [slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    slider.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    slider.minimumValue = 0.0;
    slider.maximumValue = 100.0;
    slider.value = 50.0;
    labelsslider.text = @"瘦脸";
    labelsslider.textColor =[UIColor yellowColor];
    [self.view addSubview:slider];
    [self.view addSubview:labelsslider];
    slider_chinsurgery = slider;
    
   
     self.isShowBeautyView = YES;
}


//隐藏美颜选择View
- (void)hiddenBeautysliderView
{
    if(!self.isShowBeautyView) return;
    
    // 磨皮
    labelmslider.hidden = YES;;
    slider_skinsmooth.hidden = YES;
    [self.view addSubview:slider_skinsmooth];
    [self.view addSubview:labelmslider];
    
    //红润
     labelrslider.hidden = YES;
     slider_redface.hidden = YES;
     [self.view addSubview:slider_redface];
     [self.view addSubview:labelrslider];
    
    //美白
     labelrwslider.hidden = YES;
     slider_skinwhiten.hidden = YES;
     [self.view addSubview:slider_skinwhiten];
     [self.view addSubview:labelrwslider];
    
    //大眼
     labelbslider.hidden = YES;
     slider_bigeye.hidden = YES;
     [self.view addSubview:slider_bigeye];
     [self.view addSubview:labelbslider];
    
    //瘦脸
     labelsslider.hidden = YES;
     slider_chinsurgery.hidden = YES;
     [self.view addSubview:slider_chinsurgery];
     [self.view addSubview:labelsslider];
    
     self.isShowBeautyView = NO;
}


//显示滤镜选择View
- (void)showFilterChooseView
{
    if(self.isShowFilterView) return;
    self.filtercollectionView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, 20, [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
    [UIView animateWithDuration:0.25 animations:^{
        self.filtercollectionView.frame = CGRectMake(0,20, [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
    } completion:^(BOOL finished) {
        self.isShowFilterView = YES;
    }];
    
}


//隐藏滤镜选择View
- (void)hiddenFilterChooseView
{
    if(!self.isShowFilterView) return;
    self.filtercollectionView.frame = CGRectMake(0, 20, [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
    [UIView animateWithDuration:0.25 animations:^{
        self.filtercollectionView.frame = CGRectMake([UIScreen mainScreen].bounds.size.width, 20, [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
    } completion:^(BOOL finished) {
        self.isShowFilterView = NO;
    }];
}



- (UICollectionView *)filtercollectionView
{
    if(_filtercollectionView == nil)
    {
        //创建一个块状表格布局对象
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        //可以左右拉动
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        //横向最小距离
        flowLayout.minimumInteritemSpacing = 5;
      
        //设置 上/左/下/右边距 空间间隔数
        flowLayout.sectionInset = UIEdgeInsetsMake(45, 5, 0, 0);
       
         CGRect frame = CGRectMake([UIScreen mainScreen].bounds.size.width,[UIScreen mainScreen].bounds.size.height -250 , [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
        //创建一个UICollectionview
        _filtercollectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
            
        _filtercollectionView.backgroundColor = [UIColor whiteColor];
        _filtercollectionView.delegate = self;
        _filtercollectionView.dataSource = self;
        _filtercollectionView.showsHorizontalScrollIndicator = NO;
        [_filtercollectionView registerClass:[XJGARSDKFilterCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        
    }
    return _filtercollectionView;
}


- (UICollectionView *)stickercollectionView
{
    if(_stickercollectionView == nil)
    {
        //创建一个块状表格布局对象
        UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
        //可以左右拉动
        [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
        //横向最小距离
        flowLayout.minimumInteritemSpacing = 5;
        //设置 上/左/下/右边距 空间间隔数
        flowLayout.sectionInset = UIEdgeInsetsMake(15,5, 0, 0);
        
       // CGRect frame = CGRectMake([UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height -250 , [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
        
        CGRect frame = CGRectMake(25, 305 , [UIScreen mainScreen].bounds.size.width, collectionViewHeight);
        
        //创建一个UICollectionview
        _stickercollectionView = [[UICollectionView alloc] initWithFrame:frame collectionViewLayout:flowLayout];
        
        _stickercollectionView.backgroundColor = [UIColor clearColor];
        _stickercollectionView.delegate = self;
        _stickercollectionView.dataSource = self;
        _stickercollectionView.showsHorizontalScrollIndicator = NO;
        [_stickercollectionView registerClass:[XJGARSDKStickerCollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
        
    }
    return _stickercollectionView;
}



- (void)sliderValueChanged:(id)sender
{
//    CGFloat value = [(UISlider *)sender value];
    
    
//    UISlider* slider_skinsmooth;
//    UISlider* slider_redface;
//    UISlider* slider_skinwhiten;
//    UISlider* slider_bigeye;
//    UISlider* slider_chinsurgery;

    XJGARSDKSetBigEyeParam([slider_bigeye value]);
    XJGARSDKSetRedFaceParam([slider_redface value]);
    XJGARSDKSetWhiteSkinParam([slider_skinwhiten value]);
    XJGARSDKSetSkinSmoothParam([slider_skinsmooth value]);
    XJGARSDKSetThinChinParam([slider_chinsurgery value]);
}

//点击相机切换按钮
- (void)flipCameraBtnClicked
{
        camera->flip();
}


extern int g_actionType;
//点击滤镜按钮
- (void)chooseFilterBtnAction:(UIButton *)chooseFilterBtn
{
    chooseFilterBtn.selected = !chooseFilterBtn.isSelected;
    if(chooseFilterBtn.selected)
    {
        [self showFilterChooseView];
        
    }
    else
    {
        [self hiddenFilterChooseView];
    }
}

//点击美颜按钮
- (void)chooseBeautyBtnAction:(UIButton *)beautyBtn
{
    beautyBtn.selected = !beautyBtn.isSelected;
    if(beautyBtn.selected)
    {
        [self showBeautysliderView];
        
    }
    else
    {
        [self hiddenBeautysliderView];
    }
    
}




- (void)saveImageBtnClicked
{
       int width = camera->getRotatedFramebufferWidth();
       int height = camera->getRotatedFramebufferHeight();
        if (processedFrameDataForSave != 0)
        {
            delete[] processedFrameDataForSave;
            processedFrameDataForSave = 0;
        }
       processedFrameDataForSave = camera->captureAProcessedFrameData( width, height);
        
        CGDataProviderRef dataProvider = CGDataProviderCreateWithData(NULL, processedFrameDataForSave, width * height * 4 * sizeof(unsigned char), nil);
        __block CGImageRef cgImageFromBytes = CGImageCreate(width, height, 8, 32, 4 * width, CGColorSpaceCreateDeviceRGB(), kCGBitmapByteOrderDefault | kCGImageAlphaLast, dataProvider, NULL, NO, kCGRenderingIntentDefault);
        
        UIImage* finalImage = [UIImage imageWithCGImage:cgImageFromBytes scale:1.0 orientation:UIImageOrientationUp];
        UIImageWriteToSavedPhotosAlbum(finalImage, self, @selector(image:didFinishSavingWithError:contextInfo:), (__bridge void *)self);
    
        CGImageRelease(cgImageFromBytes);
        CGDataProviderRelease(dataProvider);
}


- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo
{
    NSLog(@"didFinishSaving image = %@, error = %@, contextInfo = %@", image, error, contextInfo);
    
    delete[] processedFrameDataForSave;
    processedFrameDataForSave = 0;
}


- (void)dealloc
{
        if (camera) {
            camera = 0;
        }
}

NSArray *filterarray = [NSArray arrayWithObjects:[UIImage imageNamed:@"filter_thumb_original"],
                                                 [UIImage imageNamed:@"filter_thumb_cool"],
                                                 [UIImage imageNamed:@"filter_thumb_healthy"],
                                                 [UIImage imageNamed:@"filter_thumb_emerald"],
                                                 [UIImage imageNamed:@"filter_thumb_nostalgia"],
                                                 [UIImage imageNamed:@"filter_thumb_crayon.jpg"],
                                                 [UIImage imageNamed:@"filter_thumb_evergreen"],
                                                 nil];


NSArray *skitertexterarray = [NSArray arrayWithObjects:  @"无", @"草莓猫", @"天使",@"罐头狗",@"财神爷",@"潜水",nil];



#pragma mark - collection
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (collectionView == _filtercollectionView)
    {
        return XJGARSDK_FILTER_TOTLALNUM;
    }
    
   if (collectionView == _stickercollectionView)
    {
        return  XJGARSDK_STICKER_TOTLALNUM;
    }
    else
    {
        return  1;
        
    }
    
}



- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
   
    XJGARSDKFilterCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
   
    
      //通过索引号获取文本标签的名字
    if (collectionView == _filtercollectionView)
    {
      // cell.label.text = [XJGARSDKResInterface getFilterNameByFilterIdx:(XJGARSDKFilterType)[indexPath row]];
      
        cell.imageview.image = filterarray [indexPath.row];
        
    }
    
    if (collectionView == _stickercollectionView)
    {
       
        //通过索引号获取文本标签的名字
        cell.label.text = skitertexterarray [indexPath.row];
        
        //设置cell的背景图片
        cell.imageview.image = [UIImage imageNamed:@"ic_seekbar_smallsize_thumb_light_normal"];
        cell.backgroundView = cell.imageview;
        
       
        cell.imageviewSelect.image = [UIImage imageNamed:@"ic_seekbar_thumb_normal"];
        cell.selectedBackgroundView= cell.imageviewSelect;
       
       
    }
    
    return cell;
    
}


- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake([XJGARSDKFilterCollectionViewCell getFilterCollectionViewCellHeight], [XJGARSDKFilterCollectionViewCell getFilterCollectionViewCellHeight]);
  
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
   
    if(collectionView == _filtercollectionView)
    {
        XJGARSDKChangeFilter([[XJGARSDKResInterface getFilterNameByFilterIdx:(XJGARSDKFilterType)[indexPath row]] UTF8String]);
    }
    
    if (collectionView == _stickercollectionView)
    {
        
        NSString*  stickerPaperName =[XJGARSDKResInterface getStickerNameByStickerIdx:(XJGARSDKStickerType)[indexPath row]];
           if([stickerPaperName isEqualToString:@"sticker_none"])
            {
                XJGARSDKSetShowStickerPapers(false);
            }
            else
           {
               XJGARSDKSetShowStickerPapers(true);
               XJGARSDKChangeStickpaper([stickerPaperName UTF8String]);
        
           }
       
      // [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    }
        
}


#pragma mark - XJGARSDKChangeResDelegate
//- (void)onFilterSelected:(XJGARSDKFilterType)filterIdx
//{
 //   curFilterType = filterIdx;
 //   NSString* hint = [[NSString alloc] initWithFormat:@"Filter: %@", [XJGARSDKResInterface getFilterNameByFilterIdx:filterIdx]];
 //   [textHint setText:hint];
    
 //   XJGARSDKChangeFilter([[XJGARSDKResInterface getFilterNameByFilterIdx:filterIdx] UTF8String]);
    
//}


//- (void)onStickerPaperSelected: (XJGARSDKStickerType)stickerIdx;
//{
//    curStickerType = stickerIdx;
//    NSString* hint = [[NSString alloc] initWithFormat:@"Sticker: %@", [XJGARSDKResInterface getStickerNameByStickerIdx:stickerIdx]];
//    [textHint setText:hint];
    
//    NSString*  stickerPaperName =[XJGARSDKResInterface getStickerNameByStickerIdx:stickerIdx];
//    if([stickerPaperName isEqualToString:@"sticker_none"])
//    {
//        XJGARSDKSetShowStickerPapers(false);
//    }
//    else
//    {
//       XJGARSDKSetShowStickerPapers(true);
//        XJGARSDKChangeStickpaper([stickerPaperName UTF8String]);

//    }
//}


@end
