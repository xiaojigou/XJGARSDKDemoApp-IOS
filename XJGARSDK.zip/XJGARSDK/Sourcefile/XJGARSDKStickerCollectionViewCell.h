//
//  XJGARSDKStickerCollectionViewCell.h
//  XJGARSDK
//
//  Created by gaoyi on 2018/5/17.
//  Copyright © 2018年 gaoyi. All rights reserved.
//

#ifndef XJGARSDKStickerCollectionViewCell_h
#define XJGARSDKStickerCollectionViewCell_h


#endif /* XJGARSDKStickerCollectionViewCell_h */
@interface XJGARSDKStickerCollectionViewCell : UICollectionViewCell
@property (nonatomic, strong) UIImageView *imageview;
@property (nonatomic, strong) UIImageView *imageviewSelect;
@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UILabel *labelSelect;

+ (CGFloat)getFilterCollectionViewCellHeight;
@end
