//
//  XJGARSDKFilterCollectionViewCell.m
//  XJGARSDK
//
//  Created by gaoyi on 2018/5/9.
//  Copyright © 2018年 gaoyi. All rights reserved.
//


#import "XJGARSDKFilterCollectionViewCell.h"

@implementation XJGARSDKFilterCollectionViewCell
- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        CGFloat filterImgViewW = self.contentView.bounds.size.width - 20;
        CGFloat filterImgViewH = filterImgViewW;
        CGFloat filterImgViewX = (self.contentView.bounds.size.width -filterImgViewW)*0.5;
        CGFloat filterImgViewY = 0;
        
        self.imageview = [[UIImageView alloc] initWithFrame:CGRectMake(filterImgViewX, filterImgViewY, filterImgViewW, filterImgViewH)];
        self.label = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.imageview.frame), self.contentView.bounds.size.width, 20)];
        
        [self addSubview:self.imageview];
        [self addSubview:self.label];
    }
    return self;
}

+ (CGFloat)getFilterCollectionViewCellHeight
{
    return 60+20;
}


@end
