//
//  XJGARSDKStickerCollectionViewCell.m
//  XJGARSDK
//
//  Created by gaoyi on 2018/5/17.
//  Copyright © 2018年 gaoyi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XJGARSDKStickerCollectionViewCell.h"

@implementation XJGARSDKStickerCollectionViewCell
//- (instancetype)initWithFrame:(CGRect)frame
//{
//    if(self = [super initWithFrame:frame])
 //   {
 //       CGFloat filterImgViewW = self.contentView.bounds.size.width - 20;
 //       CGFloat filterImgViewH = filterImgViewW;
 //       CGFloat filterImgViewX = (self.contentView.bounds.size.width -filterImgViewW)*0.5;
 //       CGFloat filterImgViewY = 0;
       
        
 //       self.imageview = [[UIImageView alloc] initWithFrame:CGRectMake(filterImgViewX, filterImgViewY, filterImgViewW, filterImgViewH)];
      
       // self.label = [[UILabel alloc] initWithFrame:CGRectMake(filterImgViewX, CGRectGetMaxY(self.imageview.frame), self.contentView.bounds.size.width, 20)];
 //      self.label = [[UILabel alloc] initWithFrame:CGRectMake( filterImgViewW, filterImgViewH, self.contentView.bounds.size.width, 20)];
       
//        [self.imageview  addSubview:self.label];
//        [self addSubview:self.imageview];
       
        
//        self.imageviewSelect = [[UIImageView alloc] initWithFrame:CGRectMake(filterImgViewX, filterImgViewY, filterImgViewW, filterImgViewH)];
        
//        [self.imageview  addSubview:self.imageviewSelect];
       
       
     
 //   }
//    return self;
//}


//+ (CGFloat)getFilterCollectionViewCellHeight
//{
//    return 60+20;
//}


//@end




- (instancetype)initWithFrame:(CGRect)frame
{
    if(self = [super initWithFrame:frame])
    {
        [self addSubview:self.imageview];
        [self addSubview:self.label];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat filterImgViewW = self.contentView.bounds.size.width - 20;
    CGFloat filterImgViewH = filterImgViewW;
    CGFloat filterImgViewX = (self.contentView.bounds.size.width -filterImgViewW)*0.5;
    CGFloat filterImgViewY = 0;
    
    self.imageview.frame = CGRectMake(filterImgViewX, filterImgViewY, filterImgViewW, filterImgViewH);
    //self.label = [[UILabel alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(self.imageview.frame), self.contentView.bounds.size.width, 20)];
    self.label.frame= CGRectMake(0, CGRectGetMidY(self.imageview.frame)*0.7, self.contentView.bounds.size.width, 20);
    self.imageviewSelect.frame = CGRectMake(filterImgViewX, filterImgViewY, filterImgViewW, filterImgViewH);
}



#pragma mark - lazy
+ (CGFloat)getFilterCollectionViewCellHeight
{
    return 60+20;
}

- (UIImageView *)imageview {
    if (!_imageview) {
        _imageview = [[UIImageView alloc] init];
      //  _imageview.contentMode = UIViewContentModeScaleToFill;
        
    }
    return _imageview;
}

- (UIImageView *)imageviewSelect {
    if (!_imageviewSelect) {
        _imageviewSelect = [[UIImageView alloc] init];
     //   _imageviewSelect.contentMode = UIViewContentModeScaleToFill;
        
    }
    return _imageviewSelect;
}

- (UILabel *)label {
    if (!_label) {
        _label = [[UILabel alloc] init];
        _label.textColor = [UIColor lightGrayColor];
        _label.font = [UIFont systemFontOfSize:12.0];
        _label.textAlignment = NSTextAlignmentCenter;
        _label.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.imageview addSubview:self.label];
    }
    return _label;
}

@end



