

#import <UIKit/UIKit.h>
#import "XJGARSDKResSelViewController.h"



@interface CameraSampleViewController : UIViewController <UICollectionViewDataSource,UICollectionViewDelegate,XJGARSDKChangeResDelegate>

@property (nonatomic, assign) BOOL isShowFilterView;
@property (nonatomic, assign) BOOL isShowBeautyView;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) UICollectionView *filtercollectionView;
@property (nonatomic, strong) UICollectionView *stickercollectionView;

@end

