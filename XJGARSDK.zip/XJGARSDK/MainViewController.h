

#import <UIKit/UIKit.h>


//定义一个集成至UITableViewController的类对象
/*The UITableViewController class creates a controller object that manages a table view. It implements the following behavior*/
@interface MainViewController : UITableViewController



@end

